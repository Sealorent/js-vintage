const products = [
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    },
    {
        image: './assets/images/table.svg',
        title: 'Table Basse Versailles',
        dimensions: '120x80x50 cm',
        quantity: '5',
        materials: 'Chêne massif, verre',
        price: '599 €'
    }
    // Add more products here as needed
];