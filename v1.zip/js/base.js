const tailwindConfig = {
    theme: {
        extend: {
            colors: {
                clifford: '#da373d',
            },
            fontFamily: {
                caveat : ['Caveat', 'cursive'],
                bebas : ['Bebas Neue', 'cursive'],
            },
        }
    }
};

module.exports = tailwindConfig;